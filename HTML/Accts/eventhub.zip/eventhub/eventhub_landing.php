<?php
require_once __DIR__ . '/config.php';
$user = current_user();
$initial = $user ? strtoupper(mb_substr($user['Username'], 0, 1)) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#ffffff">
  <title>EventHub — Find your next night out</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Gloock&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --ink:#171615; --muted:#77736f; --line:#e7e4e1; --paper:#fff;
      --soft:#f7f6f5; --coral:#ed626b; --orange:#f36b32; --shadow:0 10px 28px rgba(31,24,20,.08);
    }
    * { box-sizing:border-box; }
    html { scroll-behavior:smooth; }
    body { margin:0; color:var(--ink); background:var(--paper); font-family:Inter,Arial,sans-serif; }
    button,input,select { font:inherit; }
    button,a { -webkit-tap-highlight-color:transparent; }
    button { cursor:pointer; }
    .wrap { width:min(1180px, calc(100% - 64px)); margin:0 auto; }
    .topbar { height:68px; display:flex; align-items:center; justify-content:space-between; gap:24px; }
    .brand { font-family:Gloock,Georgia,serif; font-size:17px; letter-spacing:-.4px; text-decoration:none; color:var(--ink); white-space:nowrap; }
    nav { display:flex; align-items:center; justify-content:center; gap:30px; }
    nav a { color:#4d4946; font-size:12px; text-decoration:none; transition:color .2s; }
    nav a:hover { color:var(--coral); }
    .nav-actions { display:flex; align-items:center; gap:10px; }
    .pill { border:1px solid var(--ink); border-radius:99px; padding:10px 17px; font-size:11px; font-weight:600; background:#fff; color:var(--ink); }
    .pill.dark { background:#111; color:white; }
    .pill { text-decoration:none; display:inline-block; }
    .pill:hover { transform:translateY(-1px); }
    .menu-toggle { display:none; border:0; background:none; font-size:22px; }
    .hero { text-align:center; padding:55px 0 42px; }
    .eyebrow { display:inline-block; border:1px solid #efedeb; border-radius:99px; color:#8a8580; font-size:9px; letter-spacing:1.2px; padding:8px 15px; text-transform:uppercase; }
    h1,h2,h3,p { margin-top:0; }
    h1 { font-family:Gloock,Georgia,serif; font-weight:400; font-size:clamp(42px,6.2vw,76px); letter-spacing:-2.5px; line-height:1.04; margin:22px 0 13px; }
    .hero-copy { color:var(--muted); font-size:13px; margin:0 auto 27px; max-width:620px; line-height:1.7; }
    .searchbar { width:min(820px,100%); margin:0 auto 34px; display:grid; grid-template-columns:1.2fr 1fr 1fr auto; gap:4px; padding:6px; border-radius:99px; background:#f7f6f6; box-shadow:0 7px 22px rgba(0,0,0,.055); text-align:left; }
    .search-field { min-width:0; display:flex; flex-direction:column; justify-content:center; padding:7px 17px; border-right:1px solid #e8e5e3; }
    .search-field label { color:#8d8884; font-size:8px; text-transform:uppercase; letter-spacing:.7px; margin-bottom:4px; }
    .search-field input,.search-field select { border:0; outline:0; background:transparent; color:#292624; font-size:11px; width:100%; min-width:0; }
    .search-field input::placeholder { color:#55504d; opacity:1; }
    .search-button { align-self:center; border:0; border-radius:99px; background:var(--coral); color:white; padding:14px 27px; font-size:11px; font-weight:700; min-width:96px; transition:background .2s,transform .2s; }
    .search-button:hover { background:#dc505a; transform:translateY(-1px); }
    .stripe-art { position:relative; overflow:hidden; border-radius:16px; background:
      repeating-linear-gradient(90deg,rgba(132,75,56,.17) 0 3px,rgba(255,231,212,.38) 6px 10px,rgba(255,247,233,.5) 13px 17px,rgba(176,111,84,.15) 20px 24px),
      linear-gradient(105deg,#d89c80,#f4c7a9 48%,#dc9c80); }
    .stripe-art:after { content:""; position:absolute; inset:0; background:repeating-linear-gradient(90deg,transparent 0 12px,rgba(255,255,255,.2) 14px 17px,transparent 21px 29px); filter:blur(3px); }
    .hero-art { height:clamp(150px,22vw,275px); width:100%; }
    .section { padding:54px 0 58px; border-top:1px solid #f0eeec; }
    .section-head { display:flex; justify-content:space-between; align-items:end; gap:20px; margin-bottom:23px; }
    .kicker { color:#aaa39d; font-size:9px; text-transform:uppercase; letter-spacing:1.1px; margin-bottom:10px; }
    h2 { font-family:Gloock,Georgia,serif; font-size:clamp(30px,4vw,43px); font-weight:400; letter-spacing:-.8px; margin:0; }
    .text-link { border:1px solid var(--line); border-radius:99px; background:white; padding:9px 17px; color:#37322f; font-size:10px; text-decoration:none; white-space:nowrap; }
    .text-link:hover { border-color:#aaa; }
    .event-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:22px; }
    .event-card { min-width:0; border-radius:13px; padding:8px 8px 14px; box-shadow:var(--shadow); background:#fff; transition:transform .2s,box-shadow .2s; }
    .event-card:hover { transform:translateY(-4px); box-shadow:0 15px 34px rgba(31,24,20,.12); }
    .event-art { height:clamp(145px,19vw,245px); border-radius:10px; position:relative; overflow:hidden; }
    .event-art.stage { background:radial-gradient(ellipse at 50% 0%,rgba(255,145,65,.45),transparent 48%),repeating-linear-gradient(90deg,#351e35 0 4px,#713b45 7px,#d66a31 13px,#3d2444 19px); }
    .event-art.cup { background:repeating-linear-gradient(90deg,rgba(142,80,57,.15) 0 4px,rgba(255,224,202,.5) 8px 13px,rgba(255,244,227,.55) 17px 22px),linear-gradient(120deg,#d9a087,#f4c5a8); }
    .event-art.comedy { background:radial-gradient(ellipse at 45% 35%,#fa9acb 0,#e65ca7 55%,#c83c91 100%); }
    .category { position:absolute; top:12px; left:12px; border-radius:99px; padding:6px 10px; background:rgba(255,255,255,.92); color:#35302d; font-size:8px; font-weight:700; text-transform:uppercase; letter-spacing:.5px; }
    .event-info { padding:13px 8px 0; }
    .event-date { color:#9a938d; font-size:9px; text-transform:uppercase; letter-spacing:.6px; margin-bottom:7px; }
    .event-title { font-family:Gloock,Georgia,serif; font-size:20px; font-weight:400; margin-bottom:9px; }
    .event-bottom { display:flex; justify-content:space-between; align-items:center; gap:10px; }
    .price { color:#8b8580; font-size:10px; }
    .ticket-btn { background:#111; color:#fff; border:0; border-radius:99px; padding:9px 14px; font-size:9px; font-weight:700; white-space:nowrap; }
    .ticket-btn:hover { background:var(--coral); }
    .empty-state { display:none; padding:34px; text-align:center; color:var(--muted); border:1px dashed var(--line); border-radius:12px; }
    .steps { padding:30px 0 65px; }
    .steps h2 { margin-bottom:26px; }
    .step-grid { display:grid; grid-template-columns:repeat(4,1fr); border-top:1px solid #dcd8d4; padding-top:20px; gap:22px; }
    .step-num { color:#aaa39d; font-size:9px; letter-spacing:1px; margin-bottom:18px; }
    .step-title { font-family:Gloock,Georgia,serif; font-size:23px; margin-bottom:8px; }
    .step-copy { color:#85807b; font-size:10px; line-height:1.7; max-width:210px; }
    .organiser { border-top:1px solid #dedad6; padding:50px 0 70px; display:grid; grid-template-columns:.9fr 1.1fr; gap:45px; align-items:center; }
    .organiser h2 { font-size:clamp(38px,5vw,56px); line-height:1.03; margin-bottom:17px; }
    .organiser p { color:var(--muted); font-size:12px; line-height:1.7; max-width:330px; margin-bottom:20px; }
    .orange-btn { border:0; border-radius:2px; background:var(--orange); color:white; padding:12px 18px; font-size:10px; font-weight:700; }
    .orange-btn:hover { background:#df5723; }
    .organiser-art { height:clamp(220px,30vw,350px); border-radius:0; }
    footer { border-top:1px solid #eeeae7; padding:35px 0 18px; }
    .footer-grid { display:grid; grid-template-columns:1.5fr repeat(3,1fr); gap:35px; padding-bottom:35px; }
    .footer-brand p { color:#8d8781; font-size:10px; line-height:1.7; max-width:190px; margin-top:15px; }
    .footer-col h4 { color:#aaa39d; font-size:9px; letter-spacing:1px; text-transform:uppercase; margin:3px 0 14px; }
    .footer-col a { display:block; color:#4d4844; text-decoration:none; font-size:10px; margin:0 0 10px; }
    .footer-col a:hover { color:var(--coral); }
    .copyright { border-top:1px solid #eeeae7; padding-top:16px; display:flex; justify-content:space-between; color:#a39d97; font-size:9px; }
    .modal-backdrop { display:none; position:fixed; inset:0; background:rgba(18,15,13,.45); z-index:20; align-items:center; justify-content:center; padding:20px; }
    .modal-backdrop.open { display:flex; }
    .modal { width:min(440px,100%); background:white; border-radius:16px; padding:28px; box-shadow:0 24px 80px rgba(0,0,0,.2); position:relative; }
    .modal-close { position:absolute; top:13px; right:15px; border:0; background:none; font-size:23px; color:#777; }
    .modal h3 { font:400 29px Gloock,Georgia,serif; margin:0 28px 8px 0; }
    .modal p { color:var(--muted); font-size:11px; line-height:1.6; margin-bottom:20px; }
    .modal label { display:block; font-size:10px; font-weight:600; margin:13px 0 6px; }
    .modal input,.modal select { width:100%; border:1px solid var(--line); border-radius:7px; padding:11px; font-size:12px; outline:none; }
    .modal input:focus,.modal select:focus { border-color:#888; }
    .modal .submit { width:100%; margin-top:18px; border:0; border-radius:99px; background:#111; color:white; padding:13px; font-size:11px; font-weight:700; }
    .modal .submit:hover { background:var(--coral); }
    .modal-note { font-size:9px!important; margin:12px 0 0!important; color:#9a938d!important; }
    .qty-row { display:flex; justify-content:space-between; align-items:center; margin:15px 0; font-size:11px; }
    .qty-control { display:flex; align-items:center; gap:13px; }
    .qty-control button { width:27px; height:27px; border:1px solid var(--line); background:#fff; border-radius:50%; }
    .notice { display:none; padding:10px 12px; margin-top:12px; background:#f4f2ef; border-radius:7px; color:#57514c; font-size:10px; line-height:1.5; }
    .notice.show { display:block; }
    @media(max-width:760px) {
      .wrap { width:min(100% - 36px,600px); }
      .topbar { height:62px; }
      nav { display:none; position:absolute; top:62px; left:0; right:0; z-index:5; padding:18px 24px; background:#fff; box-shadow:var(--shadow); flex-direction:column; gap:18px; }
      nav.open { display:flex; }
      .menu-toggle { display:block; }
      .nav-actions .pill { padding:8px 11px; font-size:9px; }
      .hero { padding:45px 0 35px; }
      h1 { letter-spacing:-1.5px; }
      .searchbar { border-radius:18px; grid-template-columns:1fr 1fr; padding:10px; }
      .search-field { padding:9px 10px; }
      .search-field:nth-child(2) { border-right:0; }
      .search-field:nth-child(3) { border-top:1px solid #e8e5e3; }
      .search-button { width:100%; }
      .event-grid { gap:12px; }
      .event-art { height:150px; }
      .event-title { font-size:17px; }
      .ticket-btn { padding:8px 10px; }
      .organiser { grid-template-columns:1fr; gap:24px; }
      .organiser-art { grid-row:1; height:230px; }
      .footer-grid { grid-template-columns:repeat(2,1fr); }
    }
    @media(max-width:500px) {
      .nav-actions { gap:6px; }
      .nav-actions .pill { padding:8px 9px; }
      .hero { padding-top:34px; }
      h1 { font-size:43px; }
      .hero-copy { font-size:11px; }
      .searchbar { grid-template-columns:1fr 1fr; }
      .search-field:first-child { grid-column:1/-1; border-right:0; border-bottom:1px solid #e8e5e3; }
      .event-grid { grid-template-columns:1fr; }
      .event-card { display:grid; grid-template-columns:42% 1fr; gap:7px; align-items:center; }
      .event-art { height:145px; }
      .event-info { padding:8px; }
      .event-title { font-size:20px; }
      .step-grid { grid-template-columns:repeat(2,1fr); row-gap:25px; }
      .steps { padding-bottom:45px; }
      .section { padding:42px 0; }
      .footer-grid { gap:25px 15px; }
      .copyright { gap:10px; flex-wrap:wrap; }
    }

    [hidden] { display:none !important; }
#guestActions { display:flex; align-items:center; gap:10px; }
.profile-menu { position:relative; }
.profile-btn {
  width:38px; height:38px; border-radius:50%; border:1px solid var(--ink);
  background:#fff; color:var(--ink); font-size:14px; font-weight:600;
  display:grid; place-items:center; padding:0; overflow:hidden;
}
.profile-btn img { width:100%; height:100%; object-fit:cover; }
.profile-btn:hover { border-color:var(--coral); }
.profile-btn:focus-visible { outline:2px solid var(--ink); outline-offset:2px; }
.profile-dropdown {
  position:absolute; right:0; top:46px; min-width:160px; z-index:15;
  background:#fff; border:1px solid var(--line); border-radius:12px;
  box-shadow:var(--shadow); padding:6px;
}
.profile-dropdown a, .profile-dropdown button {
  display:block; width:100%; text-align:left; border:0; background:none;
  padding:10px 12px; border-radius:8px; font-size:12px; color:var(--ink); text-decoration:none;
}
.profile-dropdown a:hover, .profile-dropdown button:hover { background:var(--soft); color:var(--coral); }
  </style>
</head>
<body>
  <header class="wrap topbar">
    <a class="brand" href="eventhub_landing.php" aria-label="EventHub home">Event Hub</a>
    <button class="menu-toggle" id="menuToggle" aria-label="Toggle navigation" aria-expanded="false">☰</button>
    <nav id="mainNav" aria-label="Main navigation">
      <a href="#events" data-filter="All">Discover</a>
      <a href="#events" data-filter="Concert">Concerts</a>
      <a href="#events" data-filter="Sport">Sport</a>
      <a href="#events" data-filter="Theatre">Theatre</a>
      <a href="#organisers">Experiences</a>
    </nav>
    <div class="nav-actions">
<?php if (!$user): ?>
  <div id="guestActions">
    <a class="pill dark" id="SignUpBtn" href="eventhub_signup.php">Create Account</a>
    <a class="pill" id="LoginBtn" href="eventhub_signIn.php">Sign in</a>
  </div>
<?php else: ?>
  <div class="profile-menu" id="profileMenu">
    <button class="profile-btn" id="profileBtn" aria-label="Account menu" aria-haspopup="true" aria-expanded="false">
      <?php if (!empty($user['ProfileImg'])): ?>
        <img src="<?= e($user['ProfileImg']) ?>" alt="">
      <?php else: ?>
        <span id="profileInitial"><?= e($initial) ?></span>
      <?php endif; ?>
    </button>
    <div class="profile-dropdown" id="profileDropdown" hidden>
      <a href="eventhub_profile.php">My profile</a>
      <form method="post" action="logout.php">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
        <button type="submit" id="signOutBtn">Sign out</button>
      </form>
    </div>
  </div>
<?php endif; ?>
</div>
  </header>

  <main>
    <section class="wrap hero">
      <span class="eyebrow">Your city, your next experience</span>
      <h1>Find your next night out</h1>
      <p class="hero-copy">Concerts, sport, theatre and conferences. One place to browse, book and keep your tickets.</p>

      <form class="searchbar" id="eventSearch">
        <div class="search-field">
          <label for="keyword">Find</label>
          <input id="keyword" type="search" placeholder="Key word" aria-label="Search events by keyword">
        </div>
        <div class="search-field">
          <label for="location">Location</label>
          <input id="location" type="text" value="Kamloops, BC" aria-label="Event location">
        </div>
        <div class="search-field">
          <label for="when">When</label>
          <select id="when" aria-label="When">
            <option value="any">This month</option>
            <option value="weekend">This weekend</option>
            <option value="upcoming">Upcoming</option>
          </select>
        </div>
        <button class="search-button" type="submit">Search</button>
      </form>
      <div class="stripe-art hero-art" role="img" aria-label="Peach and cream vertical striped artwork"></div>
    </section>

    <section class="section" id="events">
      <div class="wrap">
        <div class="section-head">
          <div><div class="kicker">The good stuff</div><h2>Happening soon</h2></div>
          <a class="text-link" href="#events" id="viewAll">View all&nbsp; ↗</a>
        </div>
        <div class="event-grid" id="eventGrid">
          <article class="event-card" data-category="Concert" data-search="summer stage live music concert outdoor">
            <div class="event-art stage"><span class="category">Concert</span></div>
            <div class="event-info">
              <div class="event-date">14 Jun · 7:00 PM</div>
              <h3 class="event-title">Summer Stage</h3>
              <div class="event-bottom"><span class="price">From $35</span><button class="ticket-btn" data-event="Summer Stage" data-price="35">Get tickets</button></div>
            </div>
          </article>
          <article class="event-card" data-category="Sport" data-search="cup final football soccer sport championship">
            <div class="event-art cup"><span class="category">Sport</span></div>
            <div class="event-info">
              <div class="event-date">21 Jun · 6:30 PM</div>
              <h3 class="event-title">Cup Final</h3>
              <div class="event-bottom"><span class="price">From $28</span><button class="ticket-btn" data-event="Cup Final" data-price="28">Get tickets</button></div>
            </div>
          </article>
          <article class="event-card" data-category="Theatre" data-search="open mic club comedy theatre standup">
            <div class="event-art comedy"><span class="category">Theatre</span></div>
            <div class="event-info">
              <div class="event-date">28 Jun · 8:00 PM</div>
              <h3 class="event-title">Open Mic Club</h3>
              <div class="event-bottom"><span class="price">From $15</span><button class="ticket-btn" data-event="Open Mic Club" data-price="15">Get tickets</button></div>
            </div>
          </article>
        </div>
        <div class="empty-state" id="emptyState">No events match those filters. Try another keyword or category.</div>
      </div>
    </section>

    <section class="wrap steps">
      <div class="kicker">Easy as it should be</div>
      <h2>Four steps, no friction</h2>
      <div class="step-grid">
        <div><div class="step-num">01</div><div class="step-title">Find</div><p class="step-copy">Browse by city, date, or type.</p></div>
        <div><div class="step-num">02</div><div class="step-title">Choose</div><p class="step-copy">Pick seats in a few taps or a quick scroll.</p></div>
        <div><div class="step-num">03</div><div class="step-title">Pay</div><p class="step-copy">One checkout. Keep your receipt and tickets.</p></div>
        <div><div class="step-num">04</div><div class="step-title">Go</div><p class="step-copy">Your tickets are in your wallet, ready to scan.</p></div>
      </div>
    </section>

    <section class="wrap organiser" id="organisers">
      <div>
        <div class="kicker">For organisers</div>
        <h2>Sell out,<br>on your terms.</h2>
        <p>Custom ticket types, live sales and payouts in one dashboard.</p>
        <button class="orange-btn" id="startSelling">Start selling</button>
      </div>
      <div class="stripe-art organiser-art" role="img" aria-label="Peach and cream vertical striped artwork"></div>
    </section>
  </main>

  <footer>
    <div class="wrap">
      <div class="footer-grid">
        <div class="footer-brand"><a class="brand" href="#">Event Hub</a><p>Events and tickets, simply. Make room for more of what you love.</p></div>
        <div class="footer-col"><h4>Discover</h4><a href="#events">Concerts</a><a href="#events">Sport</a><a href="#events">Theatre</a><a href="#events">Conferences</a></div>
        <div class="footer-col"><h4>Organisers</h4><a href="#organisers">Create an event</a><a href="#organisers">Ticket types</a><a href="#organisers">Payouts</a><a href="#organisers">Pricing</a></div>
        <div class="footer-col"><h4>About us</h4><a href="#about">About</a><a href="#about">Help centre</a><a href="#about">Terms</a><a href="#about">Privacy</a></div>
      </div>
      <div class="copyright"><span>© 2026 EventHub. All rights reserved.</span><span>Made for nights worth remembering.</span></div>
    </div>
  </footer>

  <div class="modal-backdrop" id="modalBackdrop" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
    <div class="modal">
      <button class="modal-close" id="modalClose" aria-label="Close dialog">×</button>
      <div id="modalContent"></div>
    </div>
  </div>

  <script>

  const SELL_URL = <?= json_encode($user ? 'eventhub_profile.php' : 'eventhub_signup.php') ?>;

  // ---- Account menu ----
  const profileBtn = document.getElementById('profileBtn');
  const profileDropdown = document.getElementById('profileDropdown');
  if (profileBtn) {
    profileBtn.addEventListener('click', e => {
      e.stopPropagation();
      profileDropdown.hidden = !profileDropdown.hidden;
      profileBtn.setAttribute('aria-expanded', String(!profileDropdown.hidden));
    });
    document.addEventListener('click', e => {
      if (profileDropdown.contains(e.target)) return;
      profileDropdown.hidden = true; profileBtn.setAttribute('aria-expanded', 'false');
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') profileDropdown.hidden = true; });
  }

  // ---- Modal ----
  const modalBackdrop = document.getElementById('modalBackdrop');
  const modalContent = document.getElementById('modalContent');
  function openModal(html) { modalContent.innerHTML = html; modalBackdrop.classList.add('open'); }
  function closeModal() { modalBackdrop.classList.remove('open'); modalContent.innerHTML = ''; }
  document.getElementById('modalClose').addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', e => { if (e.target === modalBackdrop) closeModal(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

    const eventCards = [...document.querySelectorAll('.event-card')];
    const eventGrid = document.getElementById('eventGrid');
    const emptyState = document.getElementById('emptyState');
    let activeCategory = 'All';

    function filterEvents() {
      const term = document.getElementById('keyword').value.trim().toLowerCase();
      const place = document.getElementById('location').value.trim().toLowerCase();
      let visible = 0;
      eventCards.forEach(card => {
        const matchesTerm = !term || (card.dataset.search + ' ' + card.querySelector('.event-title').textContent).toLowerCase().includes(term);
        const matchesCategory = activeCategory === 'All' || card.dataset.category === activeCategory;
        const show = matchesTerm && matchesCategory;
        card.hidden = !show;
        if (show) visible++;
      });
      emptyState.style.display = visible ? 'none' : 'block';
      eventGrid.style.display = visible ? 'grid' : 'none';
      if (place && !/kamloops|anywhere|all locations/i.test(place)) {
        // The sample event list is local demo content; location is collected for a future live search.
        emptyState.textContent = 'These sample events are currently listed for Kamloops, BC. A live event feed can power other locations.';
        if (!visible) emptyState.style.display = 'block';
      } else {
        emptyState.textContent = 'No events match those filters. Try another keyword or category.';
      }
    }

    document.getElementById('eventSearch').addEventListener('submit', e => {
      e.preventDefault();
      activeCategory = 'All';
      filterEvents();
      document.getElementById('events').scrollIntoView({behavior:'smooth'});
    });
    document.getElementById('keyword').addEventListener('input', filterEvents);
    document.getElementById('viewAll').addEventListener('click', () => { activeCategory = 'All'; filterEvents(); });
    document.querySelectorAll('nav a[data-filter]').forEach(link => link.addEventListener('click', () => {
      activeCategory = link.dataset.filter;
      filterEvents();
      document.getElementById('mainNav').classList.remove('open');
      document.getElementById('menuToggle').setAttribute('aria-expanded','false');
    }));

    document.querySelectorAll('.ticket-btn').forEach(btn => btn.addEventListener('click', () => {
      const name = btn.dataset.event, price = Number(btn.dataset.price);
      let qty = 1;
      openModal(`
        <div class="kicker">Tickets</div>
        <h3 id="modalTitle">${name}</h3>
        <p>Choose how many tickets you'd like. Your order total updates automatically.</p>
        <div class="qty-row"><span>General admission · $${price.toFixed(2)} each</span>
          <div class="qty-control"><button type="button" id="qtyMinus" aria-label="Remove one ticket">−</button><strong id="qtyValue">1</strong><button type="button" id="qtyPlus" aria-label="Add one ticket">+</button></div>
        </div>
        <div class="qty-row"><strong>Estimated total</strong><strong id="totalValue">$${price.toFixed(2)}</strong></div>
        <button class="submit" id="checkoutBtn" type="button">Continue to checkout</button>
        <div class="notice" id="checkoutNotice">Checkout isn't connected yet. Connect this button to your ticketing and payment flow.</div>
      `);
      const update = () => {
        document.getElementById('qtyValue').textContent = qty;
        document.getElementById('totalValue').textContent = '$' + (qty * price).toFixed(2);
      };
      document.getElementById('qtyMinus').addEventListener('click', () => { qty = Math.max(1,qty-1); update(); });
      document.getElementById('qtyPlus').addEventListener('click', () => { qty = Math.min(10,qty+1); update(); });
      document.getElementById('checkoutBtn').addEventListener('click', () => document.getElementById('checkoutNotice').classList.add('show'));
    }));

    document.getElementById('startSelling').addEventListener('click', () => { location.href = SELL_URL; });
    document.getElementById('menuToggle').addEventListener('click', () => {
      const nav = document.getElementById('mainNav');
      const open = nav.classList.toggle('open');
      document.getElementById('menuToggle').setAttribute('aria-expanded', String(open));
    });
  </script>
</body>
</html>
